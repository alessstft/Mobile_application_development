package com.example.myapplication.data.models

data class UserDto(
    val id: Int,
    val name: String,
    val surname: String,
    val age: Int
)