package com.example.myapplication.domain.models

data class User(
    val name: String,
    val age: Int,
    val id: Int
)
